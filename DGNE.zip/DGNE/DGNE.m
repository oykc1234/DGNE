% This code is for the paper "Dynamic Graph Neural Evolution: An Evolutionary Framework Integrating Graph Neural Networks with Adaptive Filtering" 
% accepted by the 2025 IEEE Congress on Evolutionary Computation. The authors are Kaichen Ouyang, Shengwei Fu, Yi Chen, Huiling Chen.
% For inquiries, contact oykc@mail.ustc.edu.cn.

function [best_fitness, best_solution, Convergence_curve, X] = DGNE(N, T, lb, ub, d, f)
% DGNE: Dynamic Graph Neural Evolution Algorithm

X = lb + (ub-lb) .* rand(N, d);  % Initialize population (uniform distribution)
X = max(min(X, ub), lb);         % Boundary handling, ensuring X is within [lb, ub]

fitness = zeros(N, 1);           % Store fitness
for i = 1:N
    fitness(i) = f(X(i, :));     % Calculate initial fitness
end

% Initialize convergence curve
Convergence_curve = zeros(1, T);

% Get the initial best individual
[best_fitness, idx] = min(fitness);
best_solution = X(idx, :);

t = 0;

% Main loop
while t < T

  
    % Dynamically adjust standard deviation
    std_X = 0.0005 * exp(-16 * (t - T/2) / (T/2)); % Standard deviation adjusts with iteration progress
    
    % Get the top k individuals with the lowest function values
    % Dynamically adjust k, which decreases from 10 to 1 as iterations proceed
    k=round(0.2*N);
    [~, sorted_idx] = sort(fitness); % Sort by fitness in ascending order
    top_k_individuals = X(sorted_idx(1:k), :); % Extract top k individuals
   
    
    % Calculate the mean of the top k individuals
    mean_top_k = mean(top_k_individuals, 1); % Calculate mean

    % Generate new population around the mean of the top k individuals
    X = mean_top_k + std_X .* (randn(N, d)); % Gaussian distribution sampling
    
    X = max(min(X, ub), lb); % Boundary handling
    
    % Update population fitness
    for i = 1:N
        fitness(i) = f(X(i, :));
    end

    % Search space center
    center = mean(X);

    % Calculate the difference between individuals and the center
    diff_X = X - center;
    diff_norm = sqrt(sum(diff_X.^2, 2));     % Norm of the difference vector
    diff_norm(diff_norm == 0) = 1e-10;      % Prevent division by zero
    diff_X_norm = diff_X ./ diff_norm;      % Normalize the difference vector

    % Calculate cosine similarity matrix
    cos_sim_matrix = exp(diff_X_norm * diff_X_norm');
    
    % Build adjacency matrix and normalize
    A = cos_sim_matrix;
    A_min = min(A(:)); % Minimum value of the adjacency matrix
    A_max = max(A(:)); % Maximum value of the adjacency matrix
    A = (A - A_min + 1e-10) / (A_max - A_min + 1e-10);

    % Build normalized Laplacian matrix
    D = diag(sum(A, 2));               % Degree matrix
    epsilon = 1e-10;                   % Prevent division by zero
    D_inv_sqrt = diag(1 ./ sqrt(diag(D) + epsilon));
    L_norm = eye(N) - D_inv_sqrt * A * D_inv_sqrt; % Symmetric normalized Laplacian matrix

    % Spectral decomposition
    [U, Lambda] = eig(L_norm);        % U: Eigenvectors, Lambda: Eigenvalues
    Lambda = diag(Lambda);            % Extract eigenvalues
    disp('Lambda')
    disp(Lambda)
    % Non-linear expansion of eigenvalues and normalization to [0, 1]
    Lambda_expanded = exp(Lambda);    % Use exponential to amplify eigenvalues
    Lambda_scaled = (Lambda_expanded - min(Lambda_expanded) + 1e-10) / ...
                    (max(Lambda_expanded) - min(Lambda_expanded) + 1e-10);

    
    % High-frequency and low-frequency weights
    high_freq_weight = 0.8-(t / T)^2*0.5; % High-frequency weight, decreases with progress
    low_freq_weight = 0.2+(t / T)^2*0.5; % Low-frequency weight, increases with progress
    
    % Non-linear processing of Lambda_scaled and (1 - Lambda_scaled)
    Lambda_nonlin_high = 1-exp(-10*Lambda_scaled.^2); % High-frequency component non-linear mapping, amplifying high-frequency
    Lambda_nonlin_low = exp(-10*Lambda_scaled.^2); % Low-frequency component non-linear mapping, amplifying low-frequency
    
    % Dynamically construct filter
    g = (high_freq_weight * Lambda_nonlin_high + low_freq_weight * Lambda_nonlin_low)*2;
    %disp('g')
    %disp(g)
    % Spectral domain transformation
    X_hat = U' * X;                  % Map population to spectral domain

    % Filtering operation
    X_hat_filtered = g .* X_hat;

    % Inverse Fourier transform
    X_new = U * X_hat_filtered;
    
    % Boundary control
    X_new = max(min(X_new, ub), lb);
 
    % Calculate the fitness of the new population
    new_fitness = zeros(N, 1);
    for i = 1:N
        new_fitness(i) = f(X_new(i, :));
    end

    % Merge old and new populations
    combined_population = [X; X_new];
    combined_fitness = [fitness; new_fitness];
   
    % Get the minimum fitness and its index from the combined population
    [~, sorted_idx] = sort(combined_fitness); % Sort by fitness in ascending order
    top_k_individuals = combined_population(sorted_idx(1:k), :); % Extract top k individuals
       
    
    % Calculate the mean of the top k individuals
    mean_top_k = mean(top_k_individuals, 1); % Calculate mean
    
    % Generate new population around the mean of the top k individuals
    X = mean_top_k + std_X .* randn(N, d); % Gaussian distribution sampling
    X = max(min(X, ub), lb); % Boundary handling
    
    % Update population fitness
    for i = 1:N
        fitness(i) = f(X(i, :));
    end

    % Update the best solution
    [current_best_fitness, idx] = min(combined_fitness);
    if current_best_fitness < best_fitness
        best_fitness = current_best_fitness;
        best_solution = combined_population(idx, :);
    end

    % Update generation and convergence curve
    t = t + 1;
    Convergence_curve(t) = best_fitness;
end

end
